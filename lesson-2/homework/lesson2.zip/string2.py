txt = 'LMaasleitbtui'
print(txt[:13:2])
print(txt[1:12:2])