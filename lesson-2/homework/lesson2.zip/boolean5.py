
sentence1 = input('Enter sentence: ')
sentence2 = input('Enter sentence: ')

if len(sentence1.strip())==len(sentence2.strip()):
    print('Kiritilgan matn uzunlgi teng ')
else: 
    print('Kiritilgan matnlar uzunligi teng emas')