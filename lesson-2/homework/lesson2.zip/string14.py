first_sentence = input('First sentence: ') 
second_sentence = input('Second sentence: ')
if first_sentence==second_sentence:
    print('Kiritilgan matnlar bir hil')
else:
    print('Kiritilgan matnlar boshqa boshqa')