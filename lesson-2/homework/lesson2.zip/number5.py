selcius = float(input('Enter selsius number: '))
fahrenheit = selcius*1.8+32

print(f' {selcius} °C: = {fahrenheit} °F ')
