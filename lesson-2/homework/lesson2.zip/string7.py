sentence = "Men Olmani yaxshi ko`raman"
old_word = "Olmani"
new_word = "Shaftolini"


new_sentence = sentence.replace(old_word, new_word)


print("Yangi gap:", new_sentence)
