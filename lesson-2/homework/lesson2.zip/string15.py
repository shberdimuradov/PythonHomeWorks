text = 'World Health Organization'

result = ''
for i in text.split():
    result += i[0]

print(result)
