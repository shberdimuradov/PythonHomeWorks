
num1 = float(input('Please enter first number: '))
num2 = float(input('Please enter second number: '))

if (num1+num2)>50:
    print('Yi\'gindi 50 dan katta')
elif (num1+num2)==50:
    print('Yig\'indi 50 ga teng')
else:
    print('Yig`indi 50 dan kichik')