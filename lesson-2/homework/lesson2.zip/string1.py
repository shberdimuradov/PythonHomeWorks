name = input('What`s your name: ')
age = input('How old you: ')

print(f'Your name is {name}  and you are {age} years old.')