n = 18
if n%2==0:
    print('even number')
else:
    print('odd number')
