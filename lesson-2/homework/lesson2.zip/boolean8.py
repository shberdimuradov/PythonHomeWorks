number = float(input('Please enter first number: '))

if number>=10 and number<=20:
    print('Kiritilgan son 10 va 20 oralig`ida')
else:
    print('Kiritilgan son 10 va 20 oralig`ida emas')