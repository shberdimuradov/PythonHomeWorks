num = 19874456454
st = str(num)
print((st)[-1])