sentence = input('Please input sentence: ')

print(f'Reverse sentence: {sentence[::-1]}')