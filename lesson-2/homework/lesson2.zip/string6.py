words = 'Hello my friend Islom'
fd = 'Islom'

if fd in words:
    print('Matn topildi')
else:
    print('Matn topilmadi')
