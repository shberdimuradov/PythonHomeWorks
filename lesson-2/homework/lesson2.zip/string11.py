word = 'H1ello'

for i in word:
    if i.isdigit():
        print("Matnda raqam bor")
        break
else:
        print('Matnda raqam yo`q')