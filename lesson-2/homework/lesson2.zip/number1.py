n = float(input('Please enter a number: '))
print(round(n, 2))