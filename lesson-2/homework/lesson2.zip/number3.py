km = float(input('Please enter a km number: '))
m = km*1000
sm = km*100000

print(f'Kilometer to metr: {m} m \nKilometer to centimeter: {sm} sm') 