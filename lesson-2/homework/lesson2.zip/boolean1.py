
username = input('Please enter user name: ')
password = input('Please enter password: ')

if username.strip() !='' and password!='':
    print('Siz User name va parolni muvafaqiyatli kirtidingiz !')
else:
    print('User name va praol kiritilmadi ')
