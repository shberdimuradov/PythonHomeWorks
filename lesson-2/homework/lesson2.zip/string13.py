sentence = input('Please enter input words: ')
clean_text = ''.join(sentence.split())
print(clean_text)