
num1 = float(input('Please enter first number: '))
num2 = float(input('Please enter second number: '))

if num1 == num2:
    print('The two number are equal')
else:
    print('The two number are not equal')
