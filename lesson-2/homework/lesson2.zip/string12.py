words =  ['apple', 'banana', 'cherry']
print(repr('-'.join(words)))