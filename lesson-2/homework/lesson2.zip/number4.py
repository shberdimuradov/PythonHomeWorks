num = divmod(17,7)

print(f'Integer part: {num[0]}  \nRemainder part: {num[1]}')