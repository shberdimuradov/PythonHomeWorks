word = input('Enter the words: ')
print(f'Large: {(word.upper())} \nSmall: {(word.lower())}')