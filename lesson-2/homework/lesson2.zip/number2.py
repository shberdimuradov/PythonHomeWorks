f_num = float(input('Please enter a number: '))
s_num = float(input('Please enter a number: '))
t_num = float(input('Please enter a number: '))

print(f'Large number: {max(f_num, s_num,t_num)} and  Small number: {min(f_num, s_num,t_num)} ')