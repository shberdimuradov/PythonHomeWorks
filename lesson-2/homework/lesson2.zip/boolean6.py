
num1 = int(input('Please enter the number: '))

if num1 % 3==0 and num1 % 5==0:
    print('Siz kiritgan son 3 ga va 5 ga bo`linadi')
else:
    print('Siz kiritgan son 3 va 5 ga bo`linmaydi')